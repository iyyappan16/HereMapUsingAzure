
/**
 * Adds a  draggable marker to the map..
 *
 * @param {H.Map} map                      A HERE Map instance within the
 *                                         application
 * @param {H.mapevents.Behavior} behavior  Behavior implements
 *                                         default interactions for pan/zoom
 */

var map, marker, marker1;
var startPos = [40.74,-73.98];
var speed = 50; // km/h
var delay = 10;

// If you set the delay below 1000ms and you go to another tab,
// the setTimeout function will wait to be the active tab again
// before running the code.
// See documentation :
// https://developer.mozilla.org/en-US/docs/Web/API/WindowTimers/setTimeout#Inactive_tabs

function animateMarker(marker, coords, km_h)
{
    var target = 0;
    var km_h = km_h || 50;
    coords.push([startPos[0], startPos[1]]);
    //alert("dest");
    function goToPoint()
    {
        window.fetch("http://localhost:8081/").then(r =>r.json()).then(res => {
         // alert("***********");
        console.log(res[0]);
        console.log(res[0]["Latitude"]);
        console.log(res[0]["Longitude"]);

       // if(res.length>0)
      // {
        //  alert(res.length+"res length");
        //  coords.push(res[0]["Latitude"], res[0]["Longitude"]);
       // }
       // else{
       //   alert("No response");
       // }

        var latlng = marker.getPosition();
       
        //lng: maneuver.position.longitude} ,
        //var lng = marker.position.longitude();
        //alert("dest");
        var lat = latlng.lat;
        var lng = latlng.lng;
       
        var step = (km_h * 1000 * delay) / 3600000; // in meters
        //var icon = new H.map.Icon('icon.png');
        
        
        var Fdest = new H.map.Marker({lat:res[0]["Latitude"], lng:res[0]["Longitude"]});
        var obj = Fdest.b;
        var jobj = JSON.stringify(obj);
        var dest = JSON.parse(jobj);
      //  alert(dest);

        //marker = new H.map.Marker({lat:42.35805, lng:-71.0636});
        //var dest = new H.map.Marker({lat:42.42666395645802, lng:-83.29694509506226});
        //alert(coords[target][0]+","+coords[target][1]);
        //var dest = new H.map.Marker({lat:parseInt(coords[target][0]), lng:parseInt(coords[target][1])});
        //console.log("",dest);

        var distance = marker.getPosition().distance(dest);
       // alert(distance);
        var numStep = distance / step;
        var i = 0;
        var deltaLat = (res[0]["Latitude"] - lat) / numStep;
        var deltaLng = (res[0]["Longitude"] - lng) / numStep;
       // alert(deltaLat+","+deltaLng);
       var c=1;
        function moveMarker()
        {
            //alert("calling me "+c++);
            lat += deltaLat;
            lng += deltaLng;
            i += step;
           // alert("************"+i);
           // alert(lat+","+lng);
            if (i < distance)
            {
                //marker.setPosition(new H.map.Marker(lat, lng));
                
                marker.setVisibility(false);
               // marker1.setVisibility(false);
               // marker = new H.map.Marker({lat:lat, lng:lng},{icon:icon});
                marker = new H.map.Marker({lat:lat, lng:lng});
                map.addObject(marker);
                /* var strip = new H.geo.Strip();

                strip.pushPoint({lat:coords[target-1][0], lng:coords[target-1][1]});
                strip.pushPoint({lat:lat, lng:lng});
                map.addObject(new H.map.Polyline(
                  strip, { style: { lineWidth:2 }}
                )); */
              // var poly = new H.map.Polyline(strip);
                setTimeout(moveMarker, delay);
            }
            else
            {   //marker.setPosition(dest);
                marker.setVisibility(false);
                marker = new H.map.Marker(dest);
                map.addObject(marker);
                target++;
                alert(res.length+"c length"+target);
                if (target == res.length){ target = 0; }
                
                setTimeout(goToPoint, delay);
            }
        }
        moveMarker();
      });
    }
    goToPoint();
}




 
  /**
   * Boilerplate map initialization code starts below:
   */
  
  //Step 1: initialize communication with the platform
  var platform = new H.service.Platform({
    app_id: 'DemoAppId01082013GAL',
    app_code: 'AJKnXv84fjrb0KIHawS0Tg',
    useCIT: true,
    useHTTPS: true
  });
 
  var defaultLayers = platform.createDefaultLayers();
  
  //Step 2: initialize a map - this map is centered over Boston
    
   map = new H.Map(document.getElementById('map'),
    defaultLayers.normal.map,{
    center: {lat:40.748,lng:-73.984},
    zoom: 16
  }); 


 
   
  //Step 3: make the map interactive
  // MapEvents enables the event system
  // Behavior implements default interactions for pan/zoom (also on mobile touch environments)
    var pixelRatio = 1, // alternatively window.devicePixelRatio
		tileSize = pixelRatio === 1 ? 256 : 512,
    ppi = pixelRatio === 1 ? undefined : 320;

    var maptypes = platform.createDefaultLayers({
      tileSize: tileSize, 
      ppi: ppi
    });
  var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));
  
  // Step 4: Create the default UI:
  var ui = H.ui.UI.createDefault(map, defaultLayers, 'en-US');
  // Add the click event listener.
  //addDraggableMarker(map, behavior);
  //var icon = new H.map.Icon('icon.png');
  marker = new H.map.Marker({lat:40.748,lng:-73.984});
  map.setBaseLayer(defaultLayers.normal.traffic);

  //map.setBaseLayer(platform.getMapTileService().createTileLayer('maptile', 'normal.day', tileSize, 'png8',null, 1, true, {crossOrigin: "anonymous"}))
  map.addObject(marker);

  //marker1 = new H.map.Marker({lat:17.507097,lng:78.352844});
  // map.setBaseLayer(platform.getMapTileService().createTileLayer('maptile', 'normal.day', tileSize, 'png8',null, 1, true, {crossOrigin: "anonymous"}))
  // map.addObject(marker1);


function addClickEventListenerToMap(map) {
  // add 'tap' listener
  
  animateMarker(marker, [
    // The coordinates of each point you want the marker to go to.
    // You don't need to specify the starting position again.

  ], speed);
 
}
addClickEventListenerToMap(map);
  
  $('head').append('<link rel="stylesheet" href="https://js.api.here.com/v3/3.0/mapsjs-ui.css" type="text/css" />');
  