
/**
 * Adds a  draggable marker to the map..
 *
 * @param {H.Map} map                      A HERE Map instance within the
 *                                         application
 * @param {H.mapevents.Behavior} behavior  Behavior implements
 *                                         default interactions for pan/zoom
 */

var map, marker, marker1;
var startPos = [17.507097, 78.352844];
var speed = 50; // km/h
var delay = 100;

// If you set the delay below 1000ms and you go to another tab,
// the setTimeout function will wait to be the active tab again
// before running the code.
// See documentation :
// https://developer.mozilla.org/en-US/docs/Web/API/WindowTimers/setTimeout#Inactive_tabs

function animateMarker(marker, coords, km_h)
{
    var target = 0;
    var km_h = km_h || 50;
    coords.push([startPos[0], startPos[1]]);
    //alert("dest");
    function goToPoint()
    {
        var latlng = marker.getPosition();
       
        //lng: maneuver.position.longitude} ,
        //var lng = marker.position.longitude();
        //alert("dest");
        var lat = latlng.lat;
        var lng = latlng.lng;
       
        var step = (km_h * 1000 * delay) / 3600000; // in meters
        //var defaultIcon = new H.map.Icon("icon2.png", {size: {w: 25, h: 25}});
       // var defaultIcon = new H.map.Icon("https://image.flaticon.com/icons/svg/726/726455.svg", {size: {w: 25, h: 25}});
       // var defaultIcon = new H.map.Icon("https://image.flaticon.com/icons/svg/275/275338.svg", {size: {w: 25, h: 25}});
       var defaultIcon = new H.map.Icon("https://www.flaticon.com/premium-icon/icons/svg/1675/1675361.svg", {size: {w: 20, h: 20}});

        
        var Fdest = new H.map.Marker({lat:coords[target][0], lng:coords[target][1]});
        var obj = Fdest.b;
        var jobj = JSON.stringify(obj);
        var dest = JSON.parse(jobj);
      //  alert(dest);

        //marker = new H.map.Marker({lat:42.35805, lng:-71.0636});
        //var dest = new H.map.Marker({lat:42.42666395645802, lng:-83.29694509506226});
        //alert(coords[target][0]+","+coords[target][1]);
        //var dest = new H.map.Marker({lat:parseInt(coords[target][0]), lng:parseInt(coords[target][1])});
        //console.log("",dest);

        var distance = marker.getPosition().distance(dest);
       // alert(distance);
        var numStep = distance / step;
        var i = 0;
        var deltaLat = (coords[target][0] - lat) / numStep;
        var deltaLng = (coords[target][1] - lng) / numStep;
       // alert(deltaLat+","+deltaLng);
        function moveMarker()
        {
            lat += deltaLat;
            lng += deltaLng;
            i += step;
           // alert("************"+i);
           // alert(lat+","+lng);
            if (i < distance)
            {
                //marker.setPosition(new H.map.Marker(lat, lng));
                
                marker.setVisibility(false);
               // marker1.setVisibility(false);
               // marker = new H.map.Marker({lat:lat, lng:lng},{icon:icon});
                marker = new H.map.Marker({lat:lat, lng:lng}, {icon: defaultIcon});
                map.addObject(marker);
                /* var strip = new H.geo.Strip();

                strip.pushPoint({lat:coords[target-1][0], lng:coords[target-1][1]});
                strip.pushPoint({lat:lat, lng:lng});
                map.addObject(new H.map.Polyline(
                  strip, { style: { lineWidth:2 }}
                )); */
              // var poly = new H.map.Polyline(strip);
                setTimeout(moveMarker, delay);
            }
            else
            {   //marker.setPosition(dest);
                marker.setVisibility(false);
                marker = new H.map.Marker(dest);
                map.addObject(marker);
                target++;
                if (target == coords.length){ target = 0; }
                
                setTimeout(goToPoint, delay);
            }
        }
        moveMarker();
    }
    goToPoint();
}



 
  /**
   * Boilerplate map initialization code starts below:
   */
  
  //Step 1: initialize communication with the platform
  var platform = new H.service.Platform({
    app_id: 'DemoAppId01082013GAL',
    app_code: 'AJKnXv84fjrb0KIHawS0Tg',
    useCIT: true,
    useHTTPS: true
  });
 
  var defaultLayers = platform.createDefaultLayers();
  
  //Step 2: initialize a map - this map is centered over Boston
    
   map = new H.Map(document.getElementById('map'),
    defaultLayers.normal.map,{
    center: {lat:17.507097,lng:78.352844},
    zoom: 15
  }); 


 
   
  //Step 3: make the map interactive
  // MapEvents enables the event system
  // Behavior implements default interactions for pan/zoom (also on mobile touch environments)
    var pixelRatio = 1, // alternatively window.devicePixelRatio
		tileSize = pixelRatio === 1 ? 256 : 512,
    ppi = pixelRatio === 1 ? undefined : 320;

    var maptypes = platform.createDefaultLayers({
      tileSize: tileSize, 
      ppi: ppi
    });
    
  //var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));

  
  // Step 4: Create the default UI:
  var ui = H.ui.UI.createDefault(map, defaultLayers, 'en-US');
  // Add the click event listener.
  //addDraggableMarker(map, behavior);
  //var icon = new H.map.Icon('icon.png');
  
  marker = new H.map.Marker({lat:17.507097,lng:78.352844});
  map.setBaseLayer(defaultLayers.normal.traffic);

  //map.setBaseLayer(platform.getMapTileService().createTileLayer('maptile', 'normal.day', tileSize, 'png8',null, 1, true, {crossOrigin: "anonymous"}))
  map.addObject(marker);

  //marker1 = new H.map.Marker({lat:17.507097,lng:78.352844});
  // map.setBaseLayer(platform.getMapTileService().createTileLayer('maptile', 'normal.day', tileSize, 'png8',null, 1, true, {crossOrigin: "anonymous"}))
  // map.addObject(marker1);

  
function addClickEventListenerToMap(map) {
  // add 'tap' listener
  animateMarker(marker, [
    // The coordinates of each point you want the marker to go to.
    // You don't need to specify the starting position again.
    [17.507259, 78.352928],
    [17.507499, 78.353065],
    [17.507762, 78.353172],
    [17.507923, 78.353263],
    [17.507944, 78.353279],
    [17.508064, 78.353195],
    [17.508312, 78.352935],
    [17.508712, 78.352493],
    [17.509046, 78.352172],
    [17.509201, 78.352027],
    [17.509447, 78.351837],
    [17.509971, 78.351402],
    [17.510637, 78.350959],
    [17.511264, 78.350631],
    [17.511852, 78.350318],
    [17.512445, 78.350013],
    [17.512817, 78.349784],
    [17.513002, 78.349685],
    [17.513364, 78.349487],
    [17.514001, 78.349082],
    [17.514375, 78.348785],
    [17.51445, 78.348434],
    [17.514734, 78.348045],
    [17.515314, 78.347595],
    [17.515716, 78.346908],
    [17.516138, 78.346183],
    [17.51662, 78.345314],
    [17.516918, 78.344436],
    [17.51691, 78.343681],
    [17.516902, 78.342933],
    [17.516881, 78.342605],
    [17.51687, 78.342002],
    [17.516857, 78.341094],
    [17.516839, 78.340202],
    [17.516822, 78.339317],
    [17.516843, 78.338684],
    [17.516813, 78.338195],
    [17.516803, 78.337554],
    [17.516794, 78.336807],
    [17.516777, 78.335975],
    [17.51679, 78.335502],
    [17.516794, 78.335357],
    [17.516748, 78.335319],
    [17.516748, 78.33535],
    [17.516777, 78.33538]
  ], speed);


  animateMarker(marker, [
    // The coordinates of each point you want the marker to go to.
    // You don't need to specify the starting position again.
    [12.8419, 77.667],
    [12.84191, 77.66709],
    [12.84196, 77.66743],
    [12.84205, 77.66788],
    [12.84211, 77.66813],
    [12.8422, 77.66845],
    [12.84228, 77.66869],
    [12.84237, 77.66892],
    [12.84242, 77.66904],
    [12.8425, 77.66924],
    [12.84258, 77.66943],
    [12.84266, 77.66956],
    [12.84272, 77.66967],
    [12.84282, 77.66981],
    [12.84304, 77.67007],
    [12.84316, 77.67019],
    [12.84333, 77.67035],
    [12.84365, 77.67079],
    [12.84402, 77.67133],
    [12.84423, 77.67163],
    [12.8445, , 77.67203],
    [12.84464, 77.67222],
    [12.84474, 77.67235],
    [12.84474, 77.67235],
    [12.84431, 77.67265],
    [12.84391, 77.67297],
    [12.84389, 77.67299],
    [12.84379, 77.67306],
    [12.84362, 77.67319],
    [12.84311, 77.67359],
    [12.84311, 77.67359],
    [12.84339, 77.67404],
    [12.84339, 77.67404],
    [12.84368, 77.67382],
    [12.84371, 77.6738],
    [12.84372, 77.67379],
    [12.84375, 77.67377],
    [12.84379, 77.67374],
    [12.84383, 77.67372],
    [12.84395, 77.67363],
    [12.84403, 77.67357],
    [12.8444, 77.67327],
    [12.84529, 77.67256],
    [12.8455, 77.67229],
    [12.8455, 77.67229],
    [12.84535, 77.67224],
    [12.84533, 77.67224],
    [12.8453, 77.67223],
    [12.84527, 77.67223],
    [12.84525, 77.67224]
  ], speed);


  animateMarker(marker, [
    // The coordinates of each point you want the marker to go to.
    // You don't need to specify the starting position again.
    [21.8419, 78.667],
    [21.84191, 78.66709],
    [21.84196, 78.66743],
    [21.84205, 78.66788],
    [21.84211, 78.66813],
    [21.8422, 78.66845],
    [21.84228, 78.66869],
    [21.84237, 78.66892],
    [21.84242, 78.66904],
    [21.8425, 78.66924],
    [21.84258, 78.66943],
    [21.84266, 78.66956],
    [21.84272, 78.66967],
    [21.84282, 78.66981],
    [21.84304, 78.67007],
    [21.84316, 78.67019],
    [21.84333, 78.67035],
    [21.84365, 78.67079],
    [21.84402, 78.67133],
    [21.84423, 78.67163],
    [21.8445, , 78.67203],
    [21.84464, 78.67222],
    [21.84474, 78.67235],
    [21.84474, 78.67235],
    [21.84431, 78.67265],
    [21.84391, 78.67297],
    [21.84389, 78.67299],
    [21.84379, 78.67306],
    [21.84362, 78.67319],
    [21.84311, 78.67359],
    [21.84311, 78.67359],
    [21.84339, 78.67404],
    [21.84339, 78.67404],
    [21.84368, 78.67382],
    [21.84371, 78.6738],
    [21.84372, 78.67379],
    [21.84375, 78.67377],
    [21.84379, 78.67374],
    [21.84383, 78.67372],
    [21.84395, 78.67363],
    [21.84403, 78.67357],
    [21.8444, 78.67327],
    [21.84529, 78.67256],
    [21.8455, 78.67229],
    [21.8455, 78.67229],
    [21.84535, 78.67224],
    [21.84533, 78.67224],
    [21.8453, 78.67223],
    [21.84527, 78.67223],
    [21.84525, 78.67224]
], speed);


}
addClickEventListenerToMap(map);
  
  $('head').append('<link rel="stylesheet" href="https://js.api.here.com/v3/3.0/mapsjs-ui.css" type="text/css" />');
  